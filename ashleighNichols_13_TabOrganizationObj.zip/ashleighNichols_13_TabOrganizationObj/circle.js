//having objects in separate tabs can help organize your code

var circle = {
	x: 200,
	y: 200,
	diam: 50,
	r: 255,
	g: 123,
	b: 25
}