//this is a rectangle/object

var rectangle = {
	x: 100,
	y: 100,
	diam: 75,
	r: 15,
	g: 33,
	b: 225
}